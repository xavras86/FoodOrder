package pl.xavras.FoodOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
